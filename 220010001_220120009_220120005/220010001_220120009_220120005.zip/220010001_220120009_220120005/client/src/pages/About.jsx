export default function About() {
    return (
      <div className="page">
        <h1>About Us</h1>
        <p>This platform allows users to submit content for review and publication.</p>
      </div>
    )
  }