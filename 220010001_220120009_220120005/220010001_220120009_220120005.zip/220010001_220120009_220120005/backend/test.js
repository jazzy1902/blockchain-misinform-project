import { uploadFile } from "./pinata/upload";

uploadFile();